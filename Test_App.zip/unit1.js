// This is where you can place your Javascript code

function HelloClick(event) {
Hello
}

function MButton1Click(event) {
$('#MLabel1').html("Hello, " + $('#MEdit1').val() + "!");
}
